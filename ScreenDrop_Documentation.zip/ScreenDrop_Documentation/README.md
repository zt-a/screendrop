# ScreenDrop
Локальная система передачи файлов на Android TV и интерактивные экраны по QR-коду.

Студент открывает QR-ссылку в браузере смартфона или компьютера и отправляет файл на Android TV. Основной сценарий: смартфон создаёт Personal Hotspot, TV подключается к нему, встроенный HTTP-сервер TV принимает файл.

> Важно: Hotspot не гарантирует доступность сервера TV с телефона-хоста. До разработки полного UI необходимо проверить реальный HTTP GET и POST между физическими устройствами.

## Документы
- [Полная документация](PROJECT_DOCUMENTATION.md)
- [SRS](docs/REQUIREMENTS.md)
- [Архитектура](docs/ARCHITECTURE.md)
- [Сеть](docs/NETWORK_DESIGN.md)
- [API](docs/API_SPECIFICATION.md)
- [Передача файлов](docs/FILE_TRANSFER.md)
- [Безопасность](docs/SECURITY.md)
- [Тестирование](docs/TESTING.md)
- [Установка](docs/INSTALLATION.md)
- [Руководство пользователя](docs/USER_GUIDE.md)
- [Демонстрация](docs/DEMO_GUIDE.md)
- [Презентация](docs/PRESENTATION.md)
- [Вопросы к защите](docs/DEFENSE_QUESTIONS.md)
- [Ограничения](docs/KNOWN_LIMITATIONS.md)

Стек: Kotlin, Android SDK, Jetpack Compose, Ktor Server, Coroutines, ConnectivityManager, ZXing, HTML/CSS/JavaScript. Внешний backend не требуется.
